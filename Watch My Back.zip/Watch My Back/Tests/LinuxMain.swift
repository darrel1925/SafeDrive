import XCTest

import Watch_My_BackTests

var tests = [XCTestCaseEntry]()
tests += Watch_My_BackTests.allTests()
XCTMain(tests)